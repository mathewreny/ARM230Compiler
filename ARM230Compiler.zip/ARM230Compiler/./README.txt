Program Created by Mathew Reny
If you need help, contact me at mhreny@gmail.com

To compile you should run the Installer program.
To run this program you must change the permission
by running the following linux commands:

$> chmod 775 Installer
$> ./Installer

You only have to Install once. and you can see
exactly what the installer is doing by opening
the file using the following linux command:

$> vi Installer
