Program Created by Mathew Reny
If you need help, contact me at mhreny@gmail.com

To compile you should run the Installer program.
To run this program you must change the permission
by running the following linux commands:

$> chmod 775 Installer
$> ./Installer

You only have to Install once. and you can see
exactly what the installer is doing by opening
the file using the following linux command:

$> vi Installer

To run the program, you must specify a .s230
file to be read. If the file is a .S230 file,
you must set the "-S" flag. To run the program
you type either of the following commands:

$> ./Compiler -f file.s230
or
$> ./Compiler -f file.S230 -S

That concludes the instructions on how to
run the program. If you need help with the file
formats please read their text files.
./help/s230_file_documentation.txt
./help/S230_file_documentation.txt
