package cse.unl;

public class BEQ extends Instruction{

	public BEQ(String name) {
		super.name = name;
	}


	public String toS230() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
