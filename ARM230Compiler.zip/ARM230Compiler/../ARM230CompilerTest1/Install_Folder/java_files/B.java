package cse.unl;

public class B extends Instruction{

	public B(String name) {
		super.name = name;
	}


	public String toS230() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
