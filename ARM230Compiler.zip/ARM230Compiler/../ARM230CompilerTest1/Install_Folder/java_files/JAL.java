package cse.unl;

public class JAL extends Instruction{


	public JAL(String name) {
		super.name = name;
	}


	public String toS230() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
