package cse.unl;

public class CMP extends Instruction{

	public CMP(String name) {
		super.name = name;
	}


	public String toS230() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
