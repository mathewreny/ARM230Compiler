package cse.unl;

public class LW extends Instruction{


	public LW(String name) {
		super.name = name;
	}


	
	public String toS230() {
		// TODO Auto-generated method stub
		return null;
	}

}
